# ⛏️ NONCE Miner — Vast.ai One-Line Installer

---

## 🚀 Cara Install (1 Langkah)

Setelah VPS Vast.ai kamu aktif dan kamu sudah SSH masuk, **paste perintah ini** di terminal:

```bash
bash <(curl -fsSL https://raw.githubusercontent.com/YOUR_GITHUB/nonce-miner/main/install.sh)
```

> ⚠️ Kalau belum upload ke GitHub, pakai cara manual di bawah.

---

## 📦 Cara Manual (tanpa GitHub)

```bash
# 1. Download install script
curl -fsSL -o install.sh https://YOUR_FILE_HOST/install.sh

# 2. Jalankan
bash install.sh
```

Atau kalau sudah upload zip-nya:

```bash
# Upload dari lokal ke VPS
scp nonce-miner-vastai.zip root@IP_VPS:~/

# Di terminal VPS
unzip nonce-miner-vastai.zip
bash install.sh
```

---

## 🖥️ Cara Buka Terminal di Vast.ai

1. Login ke **vast.ai**
2. Klik instance kamu → **Connect**
3. Pilih **SSH** atau **Open SSH** (copy perintah SSH-nya)
4. Paste di terminal komputer kamu
5. Setelah masuk, paste perintah install

---

## 💬 Yang Ditanyakan Saat Install

Script akan interaktif menanyakan:

| Pertanyaan | Keterangan |
|---|---|
| 🔑 Private Key | Private key wallet (input tersembunyi) |
| 🖥️ CPU Threads | Default = semua core - 1 |
| 🌐 RPC URL | Default = `https://mainnet.base.org` |
| 📱 Telegram Bot Token | Dari @BotFather (opsional) |
| 📱 Telegram Chat ID | Dari @userinfobot (opsional) |

---

## 📱 Setup Telegram (2 menit)

1. Buka Telegram → cari **@BotFather**
2. Ketik `/newbot` → ikuti instruksi → **copy Bot Token**
3. Cari **@userinfobot** → `/start` → **copy Chat ID**
4. Masukkan saat installer menanya

Setiap mint berhasil, dapat notif seperti ini di HP:

```
⛏️ NONCE Berhasil Di-Mine!

✅ Mint ke-1 sukses!

👛 Wallet: 0xYour...

🪙 Reward: 189 NONCE
💰 Saldo: 189.00 NONCE

🔗 Tx: 0xabc123...
🔎 Lihat di BaseScan

📊 Hashrate: 35.20 MH/s
   Waktu solve: 12.4s
```

---

## ⚙️ Perintah Setelah Install

```bash
pm2 logs nonce-miner      # Pantau log realtime
pm2 status                # Cek status
pm2 stop nonce-miner      # Stop
pm2 restart nonce-miner   # Restart
tail -f ~/nonce-miner/logs/miner.log
```

---

## ⚠️ Penting

- Pastikan wallet ada **ETH di Base Mainnet** untuk gas
- Mining baru jalan setelah **genesis NONCE selesai** (miner otomatis tunggu)
- Private key **tidak pernah dikirim ke mana pun**, hanya disimpan di `.env` lokal di VPS
